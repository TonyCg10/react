import './Backdrop.css';

export const Backdrop = () => {
  return <div className="LL-Backdrop" />;
};
